//
//  GCON.h
//  birthday-keeper
//
//  Created by   chironyf on 2018/3/17.
//  Copyright © 2018年 chironyf. All rights reserved.
//

#import <Foundation/Foundation.h>

extern float const themeRed;
extern float const themeGreen;
extern float const themeBlue;
extern float const themeAlpha;

extern float const themeTextRed;
extern float const themeTextGreen;
extern float const themeTextBlue;

extern float const themeCellRed;
extern float const themeCellGreen;
extern float const themeCellBlue;

extern float const themeCellLineRed;
extern float const themeCellLineGreen;
extern float const themeCellLineBlue;

@interface GCON : NSObject

@end
