//
//  GCON.m
//  birthday-keeper
//
//  Created by   chironyf on 2018/3/17.
//  Copyright © 2018年 chironyf. All rights reserved.
//

#import "GCON.h"

//背景色
float const themeRed = 13.f / 255.f;
float const themeGreen = 13.f / 255.f;
float const themeBlue = 13.f / 255.f;
float const themeAlpha = 1.f;

//导航栏按钮颜色
float const themeTextRed = 253.f / 255.f;
float const themeTextGreen = 148.f / 255.f;
float const themeTextBlue = 38.f / 255.f;

//cell颜色
float const themeCellRed = 30.f / 255.f;
float const themeCellGreen = 30.f / 255.f;
float const themeCellBlue = 30.f / 255.f;

//cell分隔线颜色
float const themeCellLineRed = 39.f / 255.f;
float const themeCellLineGreen = 39.f / 255.f;
float const themeCellLineBlue = 39.f / 255.f;


@implementation GCON

@end

