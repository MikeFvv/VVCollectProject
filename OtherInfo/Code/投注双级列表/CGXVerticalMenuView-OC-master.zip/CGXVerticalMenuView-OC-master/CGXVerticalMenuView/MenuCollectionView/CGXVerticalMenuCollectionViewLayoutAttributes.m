//
//  CGXVerticalMenuCollectionViewLayoutAttributes.m
//  CGXVerticalMenuView-OC
//
//  Created by CGX on 2018/05/01.
//  Copyright © 2019 CGX. All rights reserved.
//

#import "CGXVerticalMenuCollectionViewLayoutAttributes.h"

@implementation CGXVerticalMenuCollectionViewLayoutAttributes

@end
