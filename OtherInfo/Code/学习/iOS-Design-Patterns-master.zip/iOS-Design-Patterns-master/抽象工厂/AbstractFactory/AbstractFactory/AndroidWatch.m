//
//  AndroidWatch.m
//  AbstractFactory
//
//  Created by 王磊 on 16/3/3.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "AndroidWatch.h"

@implementation AndroidWatch

- (void)displayTime
{
    NSLog(@"android Watch");
}

@end
