//
//  Factory.m
//  AbstractFactory
//
//  Created by 王磊 on 16/3/3.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "Factory.h"

@implementation Factory

- (Phone *)createPhone
{
    return nil;
}

- (Watch *)createWatch
{
    return nil;
}

@end
