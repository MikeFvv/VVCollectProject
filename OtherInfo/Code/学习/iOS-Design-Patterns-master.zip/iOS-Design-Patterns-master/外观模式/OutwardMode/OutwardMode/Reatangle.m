//
//  Reatangle.m
//  OutwardMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "Reatangle.h"

@implementation Reatangle

- (void)draw
{
    NSLog(@"画一个矩形,宽：%f, 高：%f", self.width, self.height);
}

@end
