//
//  Shape.m
//  OutwardMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "Shape.h"

@implementation Shape

- (void)draw
{
    
}

@end
