//
//  CircleShape.m
//  OutwardMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "CircleShape.h"

@implementation CircleShape

- (void)draw
{
    NSLog(@"画一个圆,半径：%ld", (long)self.radius);
}

@end
