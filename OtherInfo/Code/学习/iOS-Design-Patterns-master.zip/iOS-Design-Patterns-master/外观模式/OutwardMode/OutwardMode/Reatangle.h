//
//  Reatangle.h
//  OutwardMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "Shape.h"
#import <UIKit/UIKit.h>

@interface Reatangle : Shape

@property (nonatomic, assign) CGFloat   width;
@property (nonatomic, assign) CGFloat   height;


@end
