//
//  CircleShape.h
//  OutwardMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "Shape.h"

@interface CircleShape : Shape

@property (nonatomic, assign) NSInteger radius;

@end
