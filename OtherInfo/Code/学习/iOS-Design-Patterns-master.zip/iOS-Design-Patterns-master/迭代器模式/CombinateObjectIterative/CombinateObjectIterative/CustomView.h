//
//  CustomView.h
//  CombinateObjectIterative
//
//  Created by 王磊 on 16/3/8.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "IterativeProtocol.h"

@interface CustomView : UIView <IterativeProtocol>

@end
