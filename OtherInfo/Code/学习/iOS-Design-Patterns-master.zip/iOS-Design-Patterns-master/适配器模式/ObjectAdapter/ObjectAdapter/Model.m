//
//  Model.m
//  ObjectAdapter
//
//  Created by 王磊 on 16/5/10.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "Model.h"

@implementation Model

@end
