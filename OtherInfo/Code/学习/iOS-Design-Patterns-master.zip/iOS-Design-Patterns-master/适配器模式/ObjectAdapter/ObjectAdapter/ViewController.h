//
//  ViewController.h
//  ObjectAdapter
//
//  Created by 王磊 on 16/5/10.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

