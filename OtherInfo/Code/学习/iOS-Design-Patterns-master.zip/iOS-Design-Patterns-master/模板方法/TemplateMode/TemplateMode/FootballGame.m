//
//  FootballGame.m
//  TemplateMode
//
//  Created by 王磊 on 16/3/8.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "FootballGame.h"

@implementation FootballGame

- (void)initGame
{
    NSLog(@"init football game.");
}

- (void)playGame
{
    NSLog(@"play football game.");
}

- (void)pauseGame
{
    NSLog(@"pause football game.");
}

- (void)saveGame
{
    NSLog(@"save football game.");
}

- (void)exitGame
{
    NSLog(@"exit football game.");
}

@end
