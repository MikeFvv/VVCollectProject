//
//  AbstractImplement.m
//  BridgeModeTest
//
//  Created by 王磊 on 16/3/4.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "AbstractImplement.h"

@implementation AbstractImplement

- (void)commandWithType:(CommandType)type
{

}

@end
