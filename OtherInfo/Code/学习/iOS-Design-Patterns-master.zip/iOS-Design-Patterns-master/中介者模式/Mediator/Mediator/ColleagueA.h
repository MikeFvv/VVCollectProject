//
//  ColleagueA.h
//  Mediator
//
//  Created by 王磊 on 16/5/12.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "AbstractColleague.h"

@interface ColleagueA : AbstractColleague

@property (nonatomic, assign) NSInteger count;

- (void)setCountNumber:(NSInteger)count;

@end
