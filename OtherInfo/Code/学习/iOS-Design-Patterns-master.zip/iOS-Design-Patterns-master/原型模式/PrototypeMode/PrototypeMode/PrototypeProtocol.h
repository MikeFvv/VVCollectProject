//
//  PrototypeProtocol.h
//  PrototypeMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol PrototypeProtocol <NSObject>

- (id)clone;

@end
