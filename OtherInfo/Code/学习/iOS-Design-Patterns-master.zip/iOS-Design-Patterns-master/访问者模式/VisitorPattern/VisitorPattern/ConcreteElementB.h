//
//  ConcreteElementB.h
//  VisitorPattern
//
//  Created by wanglei on 16/5/14.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ElementProtocol.h"

@interface ConcreteElementB : NSObject <ElementProtocol>

@end
