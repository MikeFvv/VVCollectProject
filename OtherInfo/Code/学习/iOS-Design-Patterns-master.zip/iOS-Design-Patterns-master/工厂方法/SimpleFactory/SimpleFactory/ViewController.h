//
//  ViewController.h
//  SimpleFactory
//
//  Created by 王磊 on 16/3/3.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

