//
//  Device.m
//  FactoryMethod
//
//  Created by 王磊 on 16/5/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "Device.h"

@implementation Device

- (void)sendMessage
{

}

@end
