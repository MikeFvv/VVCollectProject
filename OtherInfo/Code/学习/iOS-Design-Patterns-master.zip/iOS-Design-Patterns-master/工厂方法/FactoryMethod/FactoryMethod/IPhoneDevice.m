//
//  IPhoneDevice.m
//  FactoryMethod
//
//  Created by 王磊 on 16/5/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "IPhoneDevice.h"

@implementation IPhoneDevice

- (void)sendMessage
{
    NSLog(@"iphone Send Message");
}

@end
