//
//  ChainEvent.h
//  ChainMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ChainEvent : NSObject

@property (nonatomic, strong) NSString              *string;
@property (nonatomic, strong) NSMutableDictionary   *information;

@end
