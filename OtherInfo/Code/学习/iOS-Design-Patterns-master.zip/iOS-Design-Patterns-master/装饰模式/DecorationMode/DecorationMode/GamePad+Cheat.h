//
//  GamePad+Cheat.h
//  DecorationMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import "GamePad.h"

@interface GamePad (Cheat)

- (void)cheat;

@end
