//
//  CoinGamePad.h
//  DecorationMode
//
//  Created by 王磊 on 16/3/9.
//  Copyright © 2016年 wanglei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoinGamePad : NSObject

@property (nonatomic, assign) NSInteger coins;

@end
