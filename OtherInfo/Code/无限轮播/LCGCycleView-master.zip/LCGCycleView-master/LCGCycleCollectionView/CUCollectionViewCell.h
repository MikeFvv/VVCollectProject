//
//  CUCollectionViewCell.h
//  LCGCycleCollectionView
//
//  Created by 李传光 on 2019/4/17.
//  Copyright © 2019 李传光. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CUCollectionViewCell : UICollectionViewCell
@property(nonatomic ,strong)UILabel * titleLabel ;
@end

NS_ASSUME_NONNULL_END
