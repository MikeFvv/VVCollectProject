//
//  main.m
//  JSPatchOSXDemo
//
//  Created by Felix Deimel on 26.05.15.
//  Copyright (c) 2015 Lemon Mojo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
