//
//  JPInclude.h
//  JSPatchDemo
//
//  Created by bang on 15/6/29.
//  Copyright (c) 2015 bang. All rights reserved.
//

#import "JPEngine.h"

@interface JPInclude : JPExtension

@end
