//
//  JPCGContext.h
//  
//
//  Created by Albert438 on 15/7/2.
//  Copyright © 2015年 bang. All rights reserved.
//

#import "JPEngine.h"

@interface JPCGContext : JPExtension

@end
