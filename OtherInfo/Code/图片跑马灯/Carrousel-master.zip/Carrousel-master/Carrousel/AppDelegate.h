//
//  AppDelegate.h
//  Carrousel
//
//  Created by leilurong on 2017/1/3.
//  Copyright © 2017年 leilurong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

