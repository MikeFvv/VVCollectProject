//
//  FWPanPopupView.h
//  FWPopupViewOC
//
//  Created by xfg on 2018/6/8.
//  Copyright © 2018年 xfg. All rights reserved.
//  增加了拖动关闭的弹窗基类

/** ************************************************
 
 github地址：https://github.com/choiceyou/FWPopupViewOC
 bug反馈、交流群：670698309
 
 ***************************************************
 */


#import "FWPopupBaseView.h"

@interface FWPanPopupView : FWPopupBaseView

@end
