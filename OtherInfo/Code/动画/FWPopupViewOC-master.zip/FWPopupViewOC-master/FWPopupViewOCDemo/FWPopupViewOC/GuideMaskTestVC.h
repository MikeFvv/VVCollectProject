//
//  GuideMaskTestVC.h
//  FWPopupViewOC
//
//  Created by xfg on 2018/6/5.
//  Copyright © 2018年 xfg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GuideMaskTestVC : UIViewController

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *collectionViews;

@end
