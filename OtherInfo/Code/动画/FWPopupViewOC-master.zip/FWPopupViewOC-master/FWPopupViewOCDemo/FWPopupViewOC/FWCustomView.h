//
//  FWCustomView.h
//  FWPopupViewOC
//
//  Created by xfg on 2017/5/28.
//  Copyright © 2018年 xfg. All rights reserved.
//

#import "FWPopupBaseView.h"

@interface FWCustomView : FWPopupBaseView

@end
