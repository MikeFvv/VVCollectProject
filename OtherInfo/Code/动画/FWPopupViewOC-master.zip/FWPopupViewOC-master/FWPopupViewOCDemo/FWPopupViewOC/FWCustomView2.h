//
//  FWCustomView2.h
//  FWPopupViewOC
//
//  Created by xfg on 2018/6/20.
//  Copyright © 2018年 xfg. All rights reserved.
//

#import "FWPopupBaseView.h"

@interface FWCustomView2 : FWPopupBaseView

@end
