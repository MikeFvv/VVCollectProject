//
//  DemoViewController.h
//  ZMTabBarDemo
//
//  Created by 张敏 on 16/4/1.
//  Copyright © 2016年 张敏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoViewController : UIViewController

-(void)addPresentViewController:(UIViewController *)VC WithIndex:(NSInteger)index;

@end
