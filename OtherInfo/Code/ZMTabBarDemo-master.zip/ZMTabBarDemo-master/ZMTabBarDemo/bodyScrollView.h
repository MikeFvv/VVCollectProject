//
//  bodyScrollView.h
//  ZMTabBarDemo
//
//  Created by 张敏 on 16/3/29.
//  Copyright © 2016年 张敏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface bodyScrollView : UIScrollView

@end
