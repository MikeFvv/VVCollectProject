# pocker
21点小游戏扑克类Pocker ——【完整版】
2019-05-14

这个项目是写着玩得，如果喜欢请给个 Star 吧，关注我吧 ~ 万分感谢 ~



我目前是在一个小公司做着 iOS Coder，（自我认知-技术能力比较low-end）但是会写前端、后台、小程序，都有过实战项目经验。（其实写代码还是蛮好玩的一件事）

我的个人微信也可以加一下哈，如果不嫌弃，我们可以讨论技术、人生、理想、摄影、音乐、萨克斯、狗狗、VLOG、旅游、自媒体、写作、博客。。。等等


PS:单身的朋友推荐一个不错的婚恋交友平台（怦然心动婚恋App）

给你们个二维码：
![婚恋交友](http://www.ilovedsy.com/wordpress/wp-content/uploads/2019/05/prxd.jpg)

我的个人微信：

![wechat](https://upload-images.jianshu.io/upload_images/3150958-7510507ac2856852.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

我的个人网页：[ilovedsy.com](http://www.ilovedsy.com)

