//
//  CFVWaitView.h
//  WindAndCloud
//
//  Created by cfv on 2019/4/17.
//  Copyright © 2019 SpeedUp. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFVWaitView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *firstWaitPockerImgView;
@property (weak, nonatomic) IBOutlet UIImageView *secondWaitPockerImgView;
@property (weak, nonatomic) IBOutlet UIImageView *thirdWaitPockerImgView;

@end

NS_ASSUME_NONNULL_END
