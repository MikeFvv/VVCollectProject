//
//  CFVPlayerModel.h
//  WindAndCloud
//
//  Created by cfv on 2019/4/20.
//  Copyright © 2019 SpeedUp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CFVBoxPockerModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface CFVPlayerModel : NSObject
@property (nonatomic, strong) CFVBoxPockerModel *pockerBoxModel;
//@property (nonatomic, strong) CFVBoxPockerModel *secondBoxModel;
//@property (nonatomic, strong) CFVBoxPockerModel *thiredBoxModel;
@end

NS_ASSUME_NONNULL_END
