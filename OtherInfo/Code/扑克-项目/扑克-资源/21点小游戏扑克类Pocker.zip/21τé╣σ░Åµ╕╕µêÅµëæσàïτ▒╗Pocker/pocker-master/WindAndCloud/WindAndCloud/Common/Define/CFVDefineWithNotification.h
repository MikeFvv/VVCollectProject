
//
//  CFVDefineWithNotification.h
//  WindAndCloud
//
//  Created by cfv on 2019/4/24.
//  Copyright © 2019 SpeedUp. All rights reserved.
//

#ifndef CFVDefineWithNotification_h
#define CFVDefineWithNotification_h
#define GameStartNotification @"GameStartNotification"
#define GameEndNotification   @"GameEndNotification"

#endif /* CFVDefineWithNotification_h */
