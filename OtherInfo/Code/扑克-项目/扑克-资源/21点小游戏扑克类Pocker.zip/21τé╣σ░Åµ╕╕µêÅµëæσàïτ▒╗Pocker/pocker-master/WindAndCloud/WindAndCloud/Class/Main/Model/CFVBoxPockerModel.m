//
//  CFVBoxPockerModel.m
//  WindAndCloud
//
//  Created by cfv on 2019/4/22.
//  Copyright © 2019 SpeedUp. All rights reserved.
//

#import "CFVBoxPockerModel.h"

@implementation CFVBoxPockerModel

@end
