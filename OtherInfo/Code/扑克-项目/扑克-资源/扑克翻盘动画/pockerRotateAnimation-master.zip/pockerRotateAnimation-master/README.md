# pockerRotateAnimation

ios开发，一个扑克牌翻开的动画效果

效果：
![animation.gif](http://upload-images.jianshu.io/upload_images/2541004-5810b07aa6b59aaf.gif?imageMogr2/auto-orient/strip)



