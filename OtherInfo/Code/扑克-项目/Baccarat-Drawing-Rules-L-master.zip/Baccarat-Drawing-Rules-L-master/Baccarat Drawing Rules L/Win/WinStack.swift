//
//  WinStack.swift
//  Baccarat Drawing Rules L
//
//  Created by Adam on 24/04/2018.
//  Copyright © 2018 Adam Moskovich. All rights reserved.
//

import UIKit

class WinStack: UIStackView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
