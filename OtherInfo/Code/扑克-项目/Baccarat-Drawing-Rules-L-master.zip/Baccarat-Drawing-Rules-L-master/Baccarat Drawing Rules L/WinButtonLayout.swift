//
//  WinButtonLayout.swift
//  Baccarat Drawing Rules L
//
//  Created by Adam on 14/04/2018.
//  Copyright © 2018 Adam Moskovich. All rights reserved.
//

//import UIKit
//
//@IBDesignable
//class WinButtonLayout: UIButton {
//    
//    override var contentEdgeInsets: UIEdgeInsets = UIEdgeInsetsMake(8,30,8,30)
//    
//    @IBInspectable var inset:UIEdgeInsets = UIEdgeInsetsMake(8, 30, 8, 30)

//    func safeAreaInsetsDidChange() -> CGRect {
//        return UIEdgeInsetsInsetRect(bounds, inset)
//    }
//    override func contentEdgeInsets() -> CGRect {
//
//    }
//    override func contentRect(forBounds bounds: CGRect) -> CGRect {
//        return UIEdgeInsetsInsetRect(bounds, inset)
//    }

  //  private func _setup() {
        //self.contentEdgeInsets = UIEdgeInsetsMake(_:_:_:_:)
            //let insets = UIEdgeInsetsMake(8.0, 8.0, 8.0, 8.0)
           // self.contentEdgeInsets = UIEdgeInsetsMake(16.0, 30.0, 16.0, 30.0)
            //self.sizeToFit()
        //}
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

//}
