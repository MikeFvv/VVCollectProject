//
//  DrawButtonSize.swift
//  Baccarat Drawing Rules L
//
//  Created by Adam on 14/04/2018.
//  Copyright © 2018 Adam Moskovich. All rights reserved.
//

//import UIKit
//
//
//
//
//class DrawButtonSize: UIViewController {
//}
//
//    func customButton = UIEdgeInsetsMake 
//   

//extension UIButton {
    /**
     Creates an edge inset for a button
     :param: top CGFLoat
     :param: left CGFLoat
     :param: bottom CGFLoat
     :param: right CGFLoat
     */
//    func setInset(top: CGFloat, left: CGFloat, bottom: CGFloat, right: CGFloat) {
//        self.titleEdgeInsets =  UIEdgeInsetsMake(top, left, bottom, right)
//    }
//    button.setInset(top: 0.0, left: 7.0, bottom: 0.0, right: 0.0)
