//
//  ChipBoardView.h
//  Baccarat
//
//  Created by chenran on 16/6/9.
//  Copyright © 2016年 simon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChipImageView.h"

@interface ChipBoardView : UIView
@property (nonatomic, strong) UIImageView *chipView;
@property (nonatomic, strong) UILabel *chipLabel;
@end
