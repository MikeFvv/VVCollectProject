//
//  ChipImageView.h
//  Baccarat
//
//  Created by chenran on 16/6/9.
//  Copyright © 2016年 simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChipImageView : UIImageView
@property (nonatomic, strong) NSNumber *chip;
@end
