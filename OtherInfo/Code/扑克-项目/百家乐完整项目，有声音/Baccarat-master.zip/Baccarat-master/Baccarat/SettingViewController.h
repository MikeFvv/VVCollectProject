//
//  SettingViewController.h
//  Baccarat
//
//  Created by chenran on 16/6/26.
//  Copyright © 2016年 simon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController

@end
