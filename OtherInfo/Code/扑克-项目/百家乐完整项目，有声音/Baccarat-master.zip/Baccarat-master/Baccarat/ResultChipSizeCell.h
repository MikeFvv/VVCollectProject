//
//  ResultChipSizeCell.h
//  Baccarat
//
//  Created by chenran on 16/6/19.
//  Copyright © 2016年 simon. All rights reserved.
//

#import <ASOXScrollTableViewCell/ASOXScrollTableViewCell.h>

@interface ResultChipSizeCell : ASOXScrollTableViewCell

@end
