//
//  ChipsCollectionViewCell.swift
//  CSC690FinalProject
//
//  Created by Damon Zhong on 12/8/20.
//  Copyright © 2020 Damon Zhong. All rights reserved.
//

import UIKit

class ChipsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var ChipImageView: UIImageView!
    
}
