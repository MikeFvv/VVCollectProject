//
//  YLCollectionReusableView.h
//  YLTagsChooser
//
//  Created by TK-001289 on 2016/10/31.
//  Copyright © 2016年 YL. All rights reserved.
//

#import <UIKit/UIKit.h>

// test UICollectionView section header
@interface YLCollectionReusableView : UICollectionReusableView
- (void)setTitle:(NSString *)title;
@end
