//
//  Target.m
//  DesignPatten
//
//  Created by MisterBooo on 2018/5/4.
//  Copyright © 2018年 MisterBooo. All rights reserved.
//

#import "Target.h"

@implementation Target
- (void)operation
{
    // 原有的具体业务逻辑
    NSLog(@"原有的具体业务逻辑");
}

@end
