//
//  ObjectB1.m
//  DesignPatten
//
//  Created by MisterBooo on 2018/5/4.
//  Copyright © 2018年 MisterBooo. All rights reserved.
//

#import "ObjectB1.h"

@implementation ObjectB1

- (void)fetchData{
    NSLog(@"具体的逻辑处理 ObjectB1 fetchData");
    // 具体的逻辑处理
}

@end
