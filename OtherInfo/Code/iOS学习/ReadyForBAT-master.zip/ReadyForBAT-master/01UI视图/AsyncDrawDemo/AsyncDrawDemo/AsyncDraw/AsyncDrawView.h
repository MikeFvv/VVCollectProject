//
//  AsyncDrawView.h
//  AsyncDrawDemo
//
//  Created by yangyang on 2018/5/5.
//  Copyright © 2018年 mooc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AsyncDrawView : UIView

@end
