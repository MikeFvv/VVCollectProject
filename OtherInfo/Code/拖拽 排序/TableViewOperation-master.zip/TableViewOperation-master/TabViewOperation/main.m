//
//  main.m
//  TabViewOperation
//
//  Created by ym on 16/7/15.
//  Copyright © 2016年 王宁. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
