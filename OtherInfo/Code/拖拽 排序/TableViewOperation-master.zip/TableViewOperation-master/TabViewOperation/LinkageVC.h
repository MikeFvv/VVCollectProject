//
//  LinkageVC.h
//  TabViewOperation
//
//  Created by ym on 16/7/16.
//  Copyright © 2016年 王宁. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LinkageVC : UIViewController

@end
