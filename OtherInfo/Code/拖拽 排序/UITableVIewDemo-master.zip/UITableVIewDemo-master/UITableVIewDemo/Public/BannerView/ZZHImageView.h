//
//  ZZHImageView.h
//  轮播图封装练习
//
//  Created by zzh on 2017/1/13.
//  Copyright © 2017年 zzh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZHImageView : UIImageView
-(void)addTarget:(id)target action:(SEL)selector;
@end
