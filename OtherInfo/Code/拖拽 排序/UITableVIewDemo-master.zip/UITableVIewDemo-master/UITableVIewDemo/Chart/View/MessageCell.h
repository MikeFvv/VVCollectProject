//
//  MessageCell.h
//  UITableVIewDemo
//
//  Created by zzh on 2017/1/17.
//  Copyright © 2017年 zzh. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MessageModal;

@interface MessageCell : UITableViewCell

@property (nonatomic,strong)MessageModal * message;



@end
