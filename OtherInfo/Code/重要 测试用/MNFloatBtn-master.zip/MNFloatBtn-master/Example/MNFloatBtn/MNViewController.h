//
//  MNViewController.h
//  MNFloatBtn
//
//  Created by miniLV on 11/10/2018.
//  Copyright (c) 2018 miniLV. All rights reserved.
//

@import UIKit;

@interface MNViewController : UIViewController

@end
