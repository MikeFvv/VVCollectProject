//
//  OneViewController.h
//  LevitationButtonDemo
//
//  Created by Lyh on 2018/3/8.
//  Copyright © 2018年 xmhccf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MNViewController.h"
@interface OneViewController : MNViewController

@end
