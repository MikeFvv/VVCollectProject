//
//  JXCategoryTitleVerticalZoomCellModel.m
//  JXCategoryView
//
//  Created by jiaxin on 2019/2/14.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "JXCategoryTitleVerticalZoomCellModel.h"

@implementation JXCategoryTitleVerticalZoomCellModel

@end
