//
//  JXCategoryComponentCellModel.m
//  DQGuess
//
//  Created by jiaxin on 2018/7/25.
//  Copyright © 2018年 jingbo. All rights reserved.
//

#import "JXCategoryIndicatorCellModel.h"

@implementation JXCategoryIndicatorCellModel

@end
