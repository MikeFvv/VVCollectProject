//
//  JXCategoryTitleSortCellModel.m
//  JXCategoryView
//
//  Created by jiaxin on 2019/8/9.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "JXCategoryTitleSortCellModel.h"

@implementation JXCategoryTitleSortCellModel

@end
