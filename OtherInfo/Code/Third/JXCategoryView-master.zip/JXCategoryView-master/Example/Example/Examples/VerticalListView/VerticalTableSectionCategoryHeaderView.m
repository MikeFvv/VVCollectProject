//
//  VerticalTableSectionCategoryHeaderView.m
//  JXCategoryView
//
//  Created by jiaxin on 2019/8/12.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "VerticalTableSectionCategoryHeaderView.h"

@implementation VerticalTableSectionCategoryHeaderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
