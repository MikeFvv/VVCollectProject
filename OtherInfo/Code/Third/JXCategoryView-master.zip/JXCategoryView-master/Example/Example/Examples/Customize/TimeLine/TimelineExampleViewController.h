//
//  TimelineExampleViewController.h
//  JXCategoryView
//
//  Created by jiaxin on 2019/7/23.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "ContentBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TimelineExampleViewController : ContentBaseViewController

@end

NS_ASSUME_NONNULL_END
