//
//  JXCategoryTitleSortCell.h
//  JXCategoryView
//
//  Created by jiaxin on 2019/8/9.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "JXCategoryTitleCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface JXCategoryTitleSortCell : JXCategoryTitleCell

@end

NS_ASSUME_NONNULL_END
