//
//  NestSubjectViewController.h
//  JXCategoryView
//
//  Created by jiaxin on 2019/9/11.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "ContentBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface NestSubjectViewController : ContentBaseViewController <JXCategoryListContentViewDelegate>

@end

NS_ASSUME_NONNULL_END
