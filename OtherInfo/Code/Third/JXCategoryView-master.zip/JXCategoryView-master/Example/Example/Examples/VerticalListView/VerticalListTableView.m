//
//  VerticalListTableView.m
//  JXCategoryView
//
//  Created by jiaxin on 2019/8/12.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "VerticalListTableView.h"

@implementation VerticalListTableView

- (void)layoutSubviews {
    [super layoutSubviews];

    self.layoutSubviewsCallback();
}

@end
