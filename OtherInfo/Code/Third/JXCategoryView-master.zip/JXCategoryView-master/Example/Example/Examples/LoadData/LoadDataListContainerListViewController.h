//
//  LoadDataListContainerListViewController.h
//  JXCategoryView
//
//  Created by jiaxin on 2018/12/19.
//  Copyright © 2018 jiaxin. All rights reserved.
//

#import "LoadDataListBaseViewController.h"
#import "JXCategoryListContainerView.h"

@interface LoadDataListContainerListViewController : LoadDataListBaseViewController <JXCategoryListContentViewDelegate>

@end

