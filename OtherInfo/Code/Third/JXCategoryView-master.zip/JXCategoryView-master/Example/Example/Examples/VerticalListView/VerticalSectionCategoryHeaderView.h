//
//  VerticalSectionCategoryHeaderView.h
//  JXCategoryView
//
//  Created by jiaxin on 2018/8/23.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JXCategoryView.h"

@interface VerticalSectionCategoryHeaderView : UICollectionReusableView

@end
