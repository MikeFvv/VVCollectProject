//
//  JXCategoryIndicatorScrollZoomLineView.h
//  JXCategoryView
//
//  Created by jiaxin on 2019/9/19.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "JXCategoryIndicatorLineView.h"

NS_ASSUME_NONNULL_BEGIN

@interface JXCategoryIndicatorScrollZoomLineView : JXCategoryIndicatorLineView

@end

NS_ASSUME_NONNULL_END
