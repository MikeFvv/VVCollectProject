//
//  VerticalSectionCategoryHeaderView.m
//  JXCategoryView
//
//  Created by jiaxin on 2018/8/23.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

#import "VerticalSectionCategoryHeaderView.h"

@implementation VerticalSectionCategoryHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.94 alpha:1];
    }
    return self;
}

@end
