//
//  JXCategoryTitleAttributeCell.h
//  JXCategoryView
//
//  Created by jiaxin on 2018/8/22.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

#import "JXCategoryTitleCell.h"

@interface JXCategoryTitleAttributeCell : JXCategoryTitleCell

@end
