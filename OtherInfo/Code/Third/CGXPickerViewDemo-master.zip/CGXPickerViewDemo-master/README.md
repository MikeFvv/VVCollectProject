# CGXPickerView
A CGXPickerView

下载链接：https://github.com/974794055/CGXPickerViewDemo.git
作者QQ号：974794055
群名称：
群   号：
版本： 2.4.1


 功能：    
  出生年月日、时间选择、省市区选择、单行选择、多行选择等所有主流APP分类切换滚动视图
 
 
