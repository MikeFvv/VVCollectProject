//
//  CGXPickerViewFramework.h
//  CGXPickerViewFramework
//
//  Created by 曹贵鑫 on 2018/9/7.
//  Copyright © 2018年 曹贵鑫. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CGXPickerViewFramework.
FOUNDATION_EXPORT double CGXPickerViewFrameworkVersionNumber;

//! Project version string for CGXPickerViewFramework.
FOUNDATION_EXPORT const unsigned char CGXPickerViewFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CGXPickerViewFramework/PublicHeader.h>

#import <CGXPickerViewFramework/CGXPickerViewFileTools.h>

