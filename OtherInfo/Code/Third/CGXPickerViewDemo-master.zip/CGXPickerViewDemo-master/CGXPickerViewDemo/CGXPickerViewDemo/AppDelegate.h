//
//  AppDelegate.h
//  CGXPickerViewDemo
//
//  Created by CGX on 2018/1/31.
//  Copyright © 2018年 CGX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

