//
//  Animal.m
//  WHC_ModelSqliteKit
//
//  Created by WHC on 17/3/4.
//  Copyright © 2017年 WHC. All rights reserved.
//

#import "Animal.h"

@implementation Animal

@end
