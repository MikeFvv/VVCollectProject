//
//  Animal.h
//  WHC_ModelSqliteKit
//
//  Created by WHC on 17/3/4.
//  Copyright © 2017年 WHC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Animal : NSObject
@property (nonatomic, copy) NSString * typeName;
@property (nonatomic, assign) BOOL eat;
@end
