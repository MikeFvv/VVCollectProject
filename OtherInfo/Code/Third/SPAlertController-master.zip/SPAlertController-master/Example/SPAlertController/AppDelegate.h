//
//  AppDelegate.h
//  SPAlertController
//
//  Created by 乐升平 on 2018/12/4.
//  Copyright © 2018 乐升平. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

