//
//  CommodityListView.h
//  SPAlertController
//
//  Created by 乐升平 on 17/10/22.
//  Copyright © 2017年 iDress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommodityListView : UIView

@end
