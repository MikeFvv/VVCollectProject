//
//  ShoppingCartItem.h
//  SPAlertController
//
//  Created by 乐升平 on 17/10/21.
//  Copyright © 2017年 iDress. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShoppingCartItem : NSObject
@property (nonatomic, copy) NSString *foodName;
@property (nonatomic, assign) double price;
@end
