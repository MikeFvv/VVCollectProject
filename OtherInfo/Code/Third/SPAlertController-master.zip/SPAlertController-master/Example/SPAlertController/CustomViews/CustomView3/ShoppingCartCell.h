//
//  ShoppingCartCell.h
//  SPAlertController
//
//  Created by 乐升平 on 17/10/21.
//  Copyright © 2017年 iDress. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ShoppingCartItem;

@interface ShoppingCartCell : UITableViewCell
@property (nonatomic, strong) ShoppingCartItem *item;
@end

