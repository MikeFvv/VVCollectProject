//
//  MJWKWebViewController.h
//  MJRefreshExample
//
//  Created by Frank on 2019/10/29.
//  Copyright © 2019 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MJWKWebViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
