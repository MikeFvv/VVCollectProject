//
//  AppDelegate.h
//  UUMarqueeViewDemo
//
//  Created by youyou on 16/12/7.
//  Copyright © 2016年 iceyouyou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

