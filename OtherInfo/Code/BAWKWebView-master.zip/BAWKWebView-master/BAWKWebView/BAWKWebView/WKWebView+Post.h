//
//  WKWebView+Post.h
//  WKWebViewConteoller
//
//  Created by YLCHUN on 2017/3/11.
//  Copyright © 2017年 ylchun. All rights reserved.
//  [WKWebView loadRequest:] 支持POST请求

#import <WebKit/WebKit.h>

@interface WKWebView (Post)

@end

