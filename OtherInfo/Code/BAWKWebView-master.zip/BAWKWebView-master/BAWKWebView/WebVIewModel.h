//
//  WebVIewModel.h
//  testWebView1
//
//  Created by chenxiang on 2017/6/30.
//  Copyright © 2017年 chenxiang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebVIewModel : NSObject

@property(nonatomic, copy) NSString *contentHtml;
@property(nonatomic, assign) double height;

@end
