//
//  WebVIewModel.m
//  testWebView1
//
//  Created by chenxiang on 2017/6/30.
//  Copyright © 2017年 chenxiang. All rights reserved.
//

#import "WebVIewModel.h"

@implementation WebVIewModel

@end
