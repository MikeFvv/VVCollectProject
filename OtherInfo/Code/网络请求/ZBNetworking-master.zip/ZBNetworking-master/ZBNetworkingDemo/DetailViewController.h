//
//  DetailViewController.h
//  ZBNetworking
//
//  Created by NQ UEC on 16/8/24.
//  Copyright © 2016年 Suzhibin. All rights reserved.
//

#import "RootViewController.h"

@interface DetailViewController : RootViewController
@property (nonatomic,copy)NSString *wid;
@end
