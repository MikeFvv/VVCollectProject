//
//  MethodViewController.h
//  ZBNetworkingDemo
//
//  Created by Suzhibin on 2018/10/12.
//  Copyright © 2018年 Suzhibin. All rights reserved.
//

#import "RootViewController.h"

@interface MethodViewController : RootViewController

@end
