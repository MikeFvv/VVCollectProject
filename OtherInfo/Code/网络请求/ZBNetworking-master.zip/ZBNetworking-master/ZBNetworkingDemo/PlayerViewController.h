//
//  PlayerViewController.h
//  ZBNetworkingDemo
//
//  Created by Suzhibin on 2020/11/10.
//  Copyright © 2020 Suzhibin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PlayerViewController : UIViewController
@property(nonatomic,copy)NSString *videoUrl;
@end

NS_ASSUME_NONNULL_END
