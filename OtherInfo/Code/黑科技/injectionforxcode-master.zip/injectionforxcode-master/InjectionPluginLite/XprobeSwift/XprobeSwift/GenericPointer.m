//
//  GenericPointer.m
//  XprobeSwift
//
//  Created by John Holdsworth on 24/09/2017.
//  Copyright © 2017 John Holdsworth. All rights reserved.
//

void *xprobeGenericPointer( unsigned *opaquePointer, void *metadata ) {
    return opaquePointer;
}
