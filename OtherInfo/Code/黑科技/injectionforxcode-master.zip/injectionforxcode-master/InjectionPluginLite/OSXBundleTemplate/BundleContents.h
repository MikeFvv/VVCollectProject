//
//  BundleContents.h
//  InjectionBundle
//
//  Created by John Holdsworth on 17/01/2012.
//  Copyright (c) 2012 John Holdsworth. All rights reserved.
//

// place any definitions you want available to all injections here
