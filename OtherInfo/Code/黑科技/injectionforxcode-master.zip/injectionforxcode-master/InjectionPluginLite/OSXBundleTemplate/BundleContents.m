//
//  BundleContents.m
//  InjectionBundle
//
//  Created by John Holdsworth on 17/01/2012.
//  Copyright (c) 2012 John Holdsworth. All rights reserved.
//

// generated file with includes of main project classes

