//
//  BundleContents.h
//  InjectionLoader
//
//  Created by John Holdsworth on 17/01/2012.
//  Copyright (c) 2012 John Holdsworth. All rights reserved.
//

// move along, nothing to see here..