//
//  ViewController.h
//  UIView-WZB
//
//  Created by 王振标 on 2016/11/28.
//  Copyright © 2016年 王振标. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

