//
//  main.m
//  HWPanModalDemo
//
//  Created by Heath Wang on 08/21/2019.
//  Copyright © 2019 Heath Wang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
