//
//  HWInputTableViewCell.h
//  HWPanModal_Example
//
//  Created by heath wang on 2019/6/19.
//  Copyright © 2019 heath wang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWInputTableViewCell : UITableViewCell

@property (nonatomic, readonly) UITextField *textField;

@end

NS_ASSUME_NONNULL_END
