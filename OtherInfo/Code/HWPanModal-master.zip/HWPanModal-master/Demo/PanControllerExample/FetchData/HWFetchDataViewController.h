//
//  HWFetchDataViewController.h
//  HWPanModalDemo
//
//  Created by heath wang on 2019/9/9.
//  Copyright © 2019 Heath Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWFetchDataViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
