//
//  HWTestViewPanModalController.h
//  HWPanModalDemo
//
//  Created by heath wang on 2019/10/18.
//  Copyright © 2019 Heath Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWTestViewPanModalController : UIViewController

@end

NS_ASSUME_NONNULL_END
