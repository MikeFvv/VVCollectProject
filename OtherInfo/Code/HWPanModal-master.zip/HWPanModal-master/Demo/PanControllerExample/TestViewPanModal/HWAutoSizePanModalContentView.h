//
//  HWAutoSizePanModalContentView.h
//  HWPanModalDemo
//
//  Created by heath wang on 2019/10/18.
//  Copyright © 2019 heath wang. All rights reserved.
//

#import <HWPanModal/HWPanModal.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWAutoSizePanModalContentView : HWPanModalContentView

@end

NS_ASSUME_NONNULL_END
