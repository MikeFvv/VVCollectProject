//
//  HWCollectionPanModalView.h
//  HWPanModalDemo
//
//  Created by heath wang on 2020/1/15.
//  Copyright © 2020 wangcongling. All rights reserved.
//

#import <HWPanModal/HWPanModal.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWCollectionPanModalView : HWPanModalContentView

@end

NS_ASSUME_NONNULL_END
