//
//  HWSimplePanModalView.h
//  HWPanModalDemo
//
//  Created by heath wang on 2019/10/18.
//  Copyright © 2019 Heath Wang. All rights reserved.
//

#import <HWPanModal/HWPanModal.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWSimplePanModalView : HWPanModalContentView

@end

NS_ASSUME_NONNULL_END
