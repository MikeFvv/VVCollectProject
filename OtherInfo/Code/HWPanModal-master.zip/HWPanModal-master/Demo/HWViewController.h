//
//  HWViewController.h
//  HWPanModal
//
//  Created by HeathWang on 05/05/2019.
//  Copyright (c) 2019 HeathWang. All rights reserved.
//

@import UIKit;
@class HWDemoTypeModel;

@interface HWViewController : UIViewController

@property (nonatomic, copy) NSArray<HWDemoTypeModel *> *demoList;

@end
