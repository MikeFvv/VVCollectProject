//
//  AppDelegate.h
//  HWPanModalDemo
//
//  Created by Heath Wang on 08/21/2019.
//  Copyright © 2019 Heath Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

