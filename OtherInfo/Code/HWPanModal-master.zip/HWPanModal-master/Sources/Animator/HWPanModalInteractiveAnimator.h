//
//  HWPanModalInteractiveAnimator.h
//  HWPanModal
//
//  Created by heath wang on 2019/5/14.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWPanModalInteractiveAnimator : UIPercentDrivenInteractiveTransition

@end

NS_ASSUME_NONNULL_END
