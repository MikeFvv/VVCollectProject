//
//  HWPanModalInteractiveAnimator.m
//  HWPanModal
//
//  Created by heath wang on 2019/5/14.
//

#import "HWPanModalInteractiveAnimator.h"

@implementation HWPanModalInteractiveAnimator

- (CGFloat)completionSpeed {
    return 0.618;
}

@end
