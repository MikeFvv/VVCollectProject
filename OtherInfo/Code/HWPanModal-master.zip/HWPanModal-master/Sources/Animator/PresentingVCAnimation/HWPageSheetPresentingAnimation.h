//
//  HWPageSheetPresentingAnimation.h
//  HWPanModal-iOS10.0
//
//  Created by heath wang on 2019/9/5.
//

#import <Foundation/Foundation.h>
#import "HWPresentingVCAnimatedTransitioning.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWPageSheetPresentingAnimation : NSObject <HWPresentingViewControllerAnimatedTransitioning>

@end

NS_ASSUME_NONNULL_END
