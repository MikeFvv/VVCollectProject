//
//  UIViewController+PanModalPresenter.h
//  HWPanModal
//
//  Created by heath wang on 2019/4/29.
//

#import <UIKit/UIKit.h>
#import "HWPanModalPresenterProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (PanModalPresenter) <HWPanModalPresenter>

@end

NS_ASSUME_NONNULL_END
