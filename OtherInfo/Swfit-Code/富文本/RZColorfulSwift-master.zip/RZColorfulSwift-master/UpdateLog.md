##### 0.3.0
新增confer.text().custom(key, value) 可以添加自定义的属性
新增iOS15相关的属性方法（这里边的属性有什么效果，还没用过，我也不知道）
给Label添加tapAction, 只要添加了confer.text(“文本”).tapActionByLable("xxx") （即.rztapLabel属性），那么点击“文本”, label.rz.tapAciton()方法将被回调
给Label添加超过行数后，末尾添加"折叠" “收起”的文本以及点击事件回调

##### 0.2.2
修改使用方法 test.rz_xxxxxx为 test.rz.xxxx 

