//
//  One1ViewController.swift
//  SwiftDemo
//
//  Created by Seashore on 2019/11/18.
//  Copyright © 2019 Moon. All rights reserved.
//

import UIKit

class One1ViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "这是新的一页呦"
    }

}
