//
//  TwoViewController.swift
//  SwiftDemo
//
//  Created by Seashore on 2019/11/11.
//  Copyright © 2019 Moon. All rights reserved.
//

import UIKit

class TwoViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
