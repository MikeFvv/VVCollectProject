//
//  URLPath.swift
//  SwiftDemo
//
//  Created by Seashore on 2019/11/12.
//  Copyright © 2019 Moon. All rights reserved.
//

import UIKit

/// 统一管理接口地址
let GetPath = "get" //get接口
let PostPath = "post" //get接口
