import XCTest

import KakaJSONTests

var tests = [XCTestCaseEntry]()
tests += KakaJSONTests.allTests()
XCTMain(tests)
