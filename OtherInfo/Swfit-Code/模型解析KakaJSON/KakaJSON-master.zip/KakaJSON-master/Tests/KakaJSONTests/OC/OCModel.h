//
//  OCModel.h
//  KakaJSONTests
//
//  Created by MJ Lee on 2019/12/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OCModel : NSObject
@property (nonatomic, assign) int no;
@end

NS_ASSUME_NONNULL_END
