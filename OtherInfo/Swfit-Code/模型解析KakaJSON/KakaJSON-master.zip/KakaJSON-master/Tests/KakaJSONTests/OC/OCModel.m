//
//  OCModel.m
//  KakaJSONTests
//
//  Created by MJ Lee on 2019/12/23.
//

#import "OCModel.h"

@implementation OCModel

@end
