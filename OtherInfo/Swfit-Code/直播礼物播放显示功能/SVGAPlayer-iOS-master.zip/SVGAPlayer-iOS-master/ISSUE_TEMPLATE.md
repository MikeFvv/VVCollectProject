## Attention

* Do not ask any usage question, issue board is a issue board, accept library bugs only.
* If you are facing any usage problem, read the README again.

## Issue Template

Issue Description(What's your problem)

How To Reappear(How to reappear the issue)

Any Attachment(Provide a sample about your issue)

------ 中文分割线 ------

## 注意 

* 不要在 Issue 板块提问使用问题，Issue 板块只接受 Bug 反馈。
* 如果遇到使用上的问题，仔细阅读 README。

## Issue 模板

请尽量使用英文提交 Issue

请确切回答：问题的描述、重现方式、附件（提供一个 Demo 以重现问题）
