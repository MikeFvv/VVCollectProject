//
//  FourthViewModel.swift
//  SwiftMVVMKitDemo
//
//  Created by Mac on 16/3/7.
//  Copyright © 2016年 momo. All rights reserved.
//

import UIKit

class FourthViewModel: NSObject {

}
