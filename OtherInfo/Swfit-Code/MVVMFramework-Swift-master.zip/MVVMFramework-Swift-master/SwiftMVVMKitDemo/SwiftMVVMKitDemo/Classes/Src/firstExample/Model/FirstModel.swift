//
//  FirstModel.swift
//  SwiftMVVMKitDemo
//
//  Created by yuantao on 16/3/7.
//  Copyright © 2016年 momo. All rights reserved.
//

import UIKit

class FirstModel: NSObject {
    var title = ""
}
