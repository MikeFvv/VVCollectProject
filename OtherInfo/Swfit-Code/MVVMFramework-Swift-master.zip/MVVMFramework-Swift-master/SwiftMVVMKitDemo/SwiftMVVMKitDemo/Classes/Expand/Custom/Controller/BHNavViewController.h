//
//  BHNavViewController.h
//  HarmoniousCommunity
//
//  Created by love on 15/11/17.
//  Copyright © 2015年 love. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BHNavViewController : UINavigationController

+(void)setupNavTheme;

@end
