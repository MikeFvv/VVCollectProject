//
//  BaseViewController.swift
//  LTXiOSUtilsDemo
//
//  Created by CoderStar on 2022/3/18.
//

import Foundation

class BaseViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    }
}
