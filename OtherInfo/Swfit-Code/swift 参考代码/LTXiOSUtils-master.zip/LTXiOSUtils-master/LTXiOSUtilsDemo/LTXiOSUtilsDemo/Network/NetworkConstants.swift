//
//  NetworkConstants.swift
//  LTXiOSUtilsDemo
//
//  Created by CoderStar on 2022/3/18.
//

import Foundation

struct NetworkConstants {
    static let baseURL = URL(string: "https://www.fastmock.site/mock/5abd18409d0a2270b34088a07457e68f/LTXMock")!
}
