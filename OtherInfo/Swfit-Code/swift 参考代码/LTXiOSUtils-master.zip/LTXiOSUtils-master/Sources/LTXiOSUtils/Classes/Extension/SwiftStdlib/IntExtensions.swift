//
//  IntExtensions.swift
//  LTXiOSUtils
//
//  Created by CoderStar on 2019/12/30.
//

extension Int: TxExtensionWrapperCompatibleValue {}

extension TxExtensionWrapper where Base == Int {}
