//
//  UIImageViewExtensions.swift
//  LTXiOSUtils
//
//  Created by CoderStar on 2019/11/21.
//

import Foundation
import UIKit

extension TxExtensionWrapper where Base: UIImageView {}
