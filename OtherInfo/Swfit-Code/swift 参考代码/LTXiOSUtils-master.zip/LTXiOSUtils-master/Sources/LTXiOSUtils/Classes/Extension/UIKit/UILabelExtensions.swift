//
//  UILabelExtensions.swift
//  LTXiOSUtils
//  UILabel扩展
//  Created by CoderStar on 2020/1/2.
//

import Foundation
import UIKit

extension TxExtensionWrapper where Base: UILabel {}
