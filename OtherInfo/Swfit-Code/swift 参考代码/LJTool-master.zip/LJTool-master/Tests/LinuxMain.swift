import XCTest

import LJToolTests

var tests = [XCTestCaseEntry]()
tests += LJToolTests.allTests()
XCTMain(tests)