struct LJTool {
    var text = "Hello, World!"
}
