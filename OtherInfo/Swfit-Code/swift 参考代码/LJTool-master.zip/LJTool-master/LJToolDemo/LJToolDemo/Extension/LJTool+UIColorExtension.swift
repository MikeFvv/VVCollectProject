//
//  LJTool+UIColorExtension.swift
//  IntelligentDoor
//
//  Created by ljcoder on 2017/9/5.
//  Copyright © 2017年 shanglv. All rights reserved.
//

import LJTool
import UIKit

extension LJTool where Base: UIColor {
    
//    static var exYellow: UIColor {
//        return UIColor.lj.color(0xf3c02f)
//    }
//    
//    static var background: UIColor {
//        return UIColor.lj.color(r: 240, g: 240, b: 248)
//    }
}
