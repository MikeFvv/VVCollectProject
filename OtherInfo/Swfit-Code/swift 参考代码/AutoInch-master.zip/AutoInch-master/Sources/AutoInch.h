//
//  AutoInch.h
//  AutoInch
//
//  Created by 李响 on 2019/3/30.
//  Copyright © 2019 swift. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AutoInch.
FOUNDATION_EXPORT double AutoInchVersionNumber;

//! Project version string for AutoInch.
FOUNDATION_EXPORT const unsigned char AutoInchVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AutoInch/PublicHeader.h>


