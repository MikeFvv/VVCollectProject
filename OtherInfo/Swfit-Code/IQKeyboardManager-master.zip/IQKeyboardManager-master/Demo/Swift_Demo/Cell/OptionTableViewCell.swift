//
//  OptionTableViewCell.swift
//  Demo
//
//  Created by Iftekhar on 26/08/15.
//  Copyright (c) 2015 Iftekhar. All rights reserved.
//

class OptionTableViewCell: UITableViewCell {

    @IBOutlet var labelOption: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
