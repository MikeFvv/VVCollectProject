//
//  OCExample.m
//  BWMonitor_Example
//
//  Created by bairdweng on 2020/9/16.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

#import "OCExample.h"

@implementation OCExample
+(void)hello {
    
    NSArray *arr = [[NSArray alloc]init];
    NSLog(@"%@",arr[2]);
}
@end
