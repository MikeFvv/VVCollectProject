//
//  GKScrollView.h
//  GKPhotoBrowserDemo
//
//  Created by gaokun on 2018/8/20.
//  Copyright © 2018年 QuintGao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GKScrollView : UIScrollView

@end
