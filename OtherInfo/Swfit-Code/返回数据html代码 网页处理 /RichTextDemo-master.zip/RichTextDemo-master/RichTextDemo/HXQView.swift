//
//  HXQView.swift
//  hxquan-swift
//
//  Created by Tiny on 2018/11/29.
//  Copyright © 2018年 hxq. All rights reserved.
//

import UIKit

class HXQView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func setupUI(){
        
    }
}
