//
//  AppDelegate.h
//  WZZKeyboardDemo
//
//  Created by wyq_iMac on 2019/10/17.
//  Copyright © 2019 wzz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

