//
//  AppDelegate.m
//  WZZKeyboardDemo
//
//  Created by wyq_iMac on 2019/10/17.
//  Copyright © 2019 wzz. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}

@end
